BHARATHIY SAVIDHAN — Separate Menu Pages

Files:
- index.html      = Home
- about.html      = About
- articles.html   = Articles
- rights.html     = Rights
- makers.html     = Makers
- youtube.html    = YouTube
- style.css       = common design
- script.js       = mobile menu

Upload all 8 files to the same GitHub Pages repository folder.
The navigation links already point to the separate pages.

Replace the # links in youtube.html/footer with your real YouTube, Instagram and Contact links.
